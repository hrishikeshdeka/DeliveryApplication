package com.deka.DeliveryApplication.EndUserKafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndUserKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndUserKafkaApplication.class, args);
	}

	
}
