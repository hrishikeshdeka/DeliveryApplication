package com.deka.DeliveryApplication.EndUserKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndUserKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
