package com.deka.DeliveryApplication.DeliveryBoyKafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliveryBoyKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliveryBoyKafkaApplication.class, args);
	}
//for produce we will have to create a topic first.
	
}
