package com.deka.DeliveryApplication.DeliveryBoyKafka.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deka.DeliveryApplication.DeliveryBoyKafka.service.KafkaService;

@RestController
@RequestMapping("/location")
public class LocationController {

	@Autowired
	private KafkaService kafkaService;
	
	private Logger logger=LoggerFactory.getLogger(KafkaService.class);

	@PostMapping("/update")
	public Boolean updateLocation() {
		
		this.kafkaService.updateLocation("(" + Math.round(Math.random()*100)+" , "+ Math.round(Math.random()*100)+")");
		this.logger.info("Location updated");
		return true;
		


	}

}
