package com.deka.DeliveryApplication.DeliveryBoyKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryBoyKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
